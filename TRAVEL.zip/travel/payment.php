<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tours and Travel Payment</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    .container {
      width: 80%;
      margin: 50px auto;
    }

    form {
      border: 1px solid #ccc;
      padding: 20px;
      border-radius: 5px;
    }

    label {
      display: block;
      margin-bottom: 5px;
    }

    input[type="text"],
    input[type="email"],
    input[type="tel"],
    input[type="number"],
    select,
    textarea {
      width: 100%;
      padding: 8px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    button[type="submit"] {
      background-color: #4CAF50;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button[type="submit"]:hover {
      background-color: #45a049;
    }

    .error {
      color: red;
      font-size: 0.8em;
      margin-top: 5px;
    }

    .hidden {
      display: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Tours and Travel Payment</h2>
    <form id="paymentForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <label for="fullname">Full Name:</label>
      <input type="text" id="fullname" name="fullname" required>

      <label for="email">Email Address:</label>
      <input type="email" id="email" name="email" required>

      <label for="phone">Phone Number:</label>
      <input type="tel" id="phone" name="phone" required>

      <label for="address">Billing Address:</label>
      <textarea id="address" name="address" required></textarea>

      <label for="package">Tour Package:</label>
      <input type="text" id="package" name="package" required>

      <label for="guests">Number of Guests:</label>
      <input type="number" id="guests" name="guests" required>

      <label for="amount">Total Amount:</label>
      <input type="text" id="amount" name="amount" required>

      <label for="paymentMethod">Payment Method:</label>
      <select id="paymentMethod" name="paymentMethod" required>
        <option value="">Select Payment Method</option>
        <option value="creditCard">Credit Card</option>
        <option value="debitCard">Debit Card</option>
        <option value="paypal">PayPal</option>
        <option value="bankTransfer">Bank Transfer</option>
      </select>

      <!-- Credit Card Details -->
      <div id="creditCardDetails" class="hidden">
        <label for="cardNumber">Card Number:</label>
        <input type="text" id="cardNumber" name="cardNumber">

        <label for="expiryDate">Expiry Date:</label>
        <input type="text" id="expiryDate" name="expiryDate">

        <label for="cvv">CVV:</label>
        <input type="text" id="cvv" name="cvv">

        <label for="cardName">Name on Card:</label>
        <input type="text" id="cardName" name="cardName">
      </div>

      <!-- PayPal Details -->
      <div id="paypalDetails" class="hidden">
        <label for="paypalEmail">PayPal Email:</label>
        <input type="email" id="paypalEmail" name="paypalEmail">
      </div>

      <!-- Bank Transfer Details -->
      <div id="bankTransferDetails" class="hidden">
        <label for="bankName">Bank Name:</label>
        <input type="text" id="bankName" name="bankName">

        <label for="accountHolderName">Account Holder Name:</label>
        <input type="text" id="accountHolderName" name="accountHolderName">

        <label for="accountNumber">Account Number:</label>
        <input type="text" id="accountNumber" name="accountNumber">

        <label for="routingNumber">Routing Number:</label>
        <input type="text" id="routingNumber" name="routingNumber">
      </div>

      <input type="checkbox" id="agreeTerms" required>
      <label for="agreeTerms">I agree to the Terms and Conditions.</label>

      <button type="submit">Submit Payment</button>
    </form>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      var paymentMethod = document.getElementById('paymentMethod');
      var creditCardDetails = document.getElementById('creditCardDetails');
      var paypalDetails = document.getElementById('paypalDetails');
      var bankTransferDetails = document.getElementById('bankTransferDetails');

      paymentMethod.addEventListener('change', function () {
        var selectedOption = paymentMethod.options[paymentMethod.selectedIndex].value;

        if (selectedOption === 'creditCard') {
          creditCardDetails.classList.remove('hidden');
          paypalDetails.classList.add('hidden');
          bankTransferDetails.classList.add('hidden');
        } else if (selectedOption === 'paypal') {
          paypalDetails.classList.remove('hidden');
          creditCardDetails.classList.add('hidden');
          bankTransferDetails.classList.add('hidden');
        } else if (selectedOption === 'bankTransfer') {
          bankTransferDetails.classList.remove('hidden');
          creditCardDetails.classList.add('hidden');
          paypalDetails.classList.add('hidden');
        } else {
          creditCardDetails.classList.add('hidden');
          paypalDetails.classList.add('hidden');
          bankTransferDetails.classList.add('hidden');
        }
      });
    });
  </script>

<?php
// Function to validate email format
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Function to validate phone number format
function validatePhoneNumber($phone) {
    // Allow +, -, . and whitespace characters in phone number
    return preg_match('/^\+?\d[\d\-\s]+$/',$phone);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $package = $_POST['package'];
    $guests = $_POST['guests'];
    $amount = $_POST['amount'];
    $paymentMethod = $_POST['paymentMethod'];

    // Validate form data
    if (empty($fullname) || empty($email) || empty($phone) || empty($address) || empty($package) || empty($guests) || empty($amount) || empty($paymentMethod)) {
        // Handle empty fields
        echo "Please fill in all fields.";
    } elseif (!validateEmail($email)) {
        // Handle invalid email
        echo "Invalid email address.";
    } elseif (!validatePhoneNumber($phone)) {
        // Handle invalid phone number
        echo "Invalid phone number.";
    } else {
        // All form data is valid, proceed with payment processing

        // Interaction with payment gateway
        // Here you would send the payment details to the payment gateway for processing
        // Example code to interact with a payment gateway goes here

        // If payment is successful, redirect to thank you page
         header("Location: home.php");
        // exit();
        
        echo "Payment processed successfully. Thank you!";
    }
}


 
  ?>
</body>
</html>
