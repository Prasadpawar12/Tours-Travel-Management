<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
        /* Resetting Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            background-image: url('images/img-.jpg');
        }

        /* Header Styles */
        .contact-head {
            padding: 6% 0;
            text-align: center;
        }

        .contact-head h3 {
            color: #60B0E6;
            font-size: 2em;
            margin-bottom: 1em;
        }

        .contact-head img {
            margin: 1em;
            width: 25px;
            height: 25px;
        }

        .contact-head span {
            display: inline-block;
            width: 6%;
            height: 1px;
            background: rgba(128, 128, 128, 0.24);
            vertical-align: middle;
            margin: 0 1em;
        }

        /* Address Section Styles */
        .address {
            text-align: center;
            margin-bottom: 2em;
        }

        .address h4 {
            color: #09F;
            font-size: 1.5em;
            margin-bottom: 0.5em;
        }

        .address p {
            color: #000;
            font-size: 1.1em;
            margin-bottom: 1em;
        }

        .address h5 {
            color: #5E686F;
            font-size: 1em;
            margin-bottom: 0.5em;
        }

        .address h5 a {
            color: #5E686F;
            text-decoration: none;
        }

        .address h5 a:hover {
            color: #60B0E6;
        }

        .address h5 span {
            display: inline-block;
            width: 25px;
            height: 28px;
            margin-right: 0.5em;
            vertical-align: middle;
        }

        .address h5 span.img1 {
            background: url("../images/contact-img.png") no-repeat 0 0;
        }

        .address h5 span.img2 {
            background: url("../images/contact-img.png") no-repeat 0 -33px;
        }

        .address h5 span.img3 {
            background: url("../images/contact-img.png") no-repeat 0 -68px;
        }

        .address img {
            width: 100%;
            height: auto;
            max-width: 200px;
            display: block;
            margin: 1em auto;
        }

        /* Form Section Styles */
        .contact form {
            width: 70%;
            margin: 0 auto;
            background-color: #fff;
            padding: 2em;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .contact form input[type="text"],
        .contact form textarea {
            width: calc(100% - 2em);
            margin-bottom: 1em;
            padding: 0.5em;
            border: 1px solid #ccc;
            border-radius: 3px;
            outline: none;
        }

        .contact form textarea {
            min-height: 150px;
            resize: vertical;
        }

        .contact form input[type="submit"] {
            background-color: #60B0E6;
            color: #fff;
            border: none;
            padding: 0.5em 2em;
            font-size: 1em;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
            outline: none;
        }

        .contact form input[type="submit"]:hover {
            background-color: #3f8ecb;
        }

        /* Footer Styles */
        .footer {
            text-align: center;
            margin-top: 20px;
        }

        .footer a {
            color: #60B0E6;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer a:hover {
            color: #3f8ecb;
        }

        /* Email Container Styles */
        .email-container {
            margin-top: 20px;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <div id="section-5" class="contact section">
        <div class="contact-head">
            <h3>Contact Us</h3>
            <b><p id="successMessage" style="display: none; color: green;">Your message has been sent successfully!</p></b>
            <div class="contact-grids">
                <div class="container">
                    <div class="col-md-4 address">
                        <h4>Travel Agency</h4>
                        <p>NEED HELP BOOKING PACKAGE<br>For fantastic suggestions you may also call our travel expert</p>
                        <h5>(+91) 8799802445&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;8766907061</h5>
                        <h5>Nashik</h5>
                        <img src="images/contac.jpg" alt="Contact Image">
                    </div>
                    <div class="col-md-8 contact">
                        <form id="contactForm" method="post" onsubmit="return submitForm()">
                            <input type="text" name="t1" placeholder="Name" required pattern="[a-zA-z1 _]{1,50}">
                            <input type="text" name="t2" placeholder="Contact No" required pattern="[0-9]{10,12}">
                            <input type="text" name="t3" placeholder="Email" required pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}">

                            <textarea name="t4" placeholder="Message" required></textarea>
                            <input type="submit" value="Send message" name="sbmt">
                        </form>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">
        <a href="home.php" onclick="goBack()">Back</a>
    </div>

    <div class="email-container">
        <h4>Email Us</h4>
        <p>If you have any inquiries or questions, feel free to send us an email at <a href="mailto:prasadvpawar3@gmail.com">prasadvpawar3@gmail.com</a></p>
    </div>

    <script>
        function submitForm() {
            // Form data
            var formData = {
                name: document.getElementsByName('t1')[0].value,
                contact: document.getElementsByName('t2')[0].value,
                email: document.getElementsByName('t3')[0].value,
                message: document.getElementsByName('t4')[0].value
            };

            // Here, you can perform your form submission logic, such as sending an AJAX request
            // For demonstration purposes, let's assume the form submission is successful
            // You can replace this with your actual form submission logic

            // Display a success message
            document.getElementById("successMessage").style.display = "block";

            // Reset the form
            document.getElementById("contactForm").reset();

            // Return false to prevent the form from submitting and refreshing the page
            return false;
        }

        function goBack() {
            window.history.back();
        }
    </script>
</body>
</html>
