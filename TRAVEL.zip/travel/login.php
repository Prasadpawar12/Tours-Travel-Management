<?php
include 'dbcon.php';
session_start();
if(isset($_POST['submit'])){

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = mysqli_real_escape_string($conn, md5($_POST['password']));

    $select = mysqli_query($conn,"SELECT * FROM  `user_form` WHERE email = '$email' AND password ='$pass'") or die('query failed');

    if(mysqli_num_rows($select) > 0){
    $row = mysqli_fetch_assoc($select);
     $_SESSION['user_id'] = $row['id'];
    header('location:home.php');
    
}else{
    $message[] = 'incorrect password or email !';
}

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

        :root {
            --blue: #3498db;
            --red: #e74c3c;
            --orange: #f39c12;
            --black: #333;
            --white: #fff;
            --light-bg: #f8f9fa;
            --border: 2px solid var(--black);
            --form-bg: rgba(255, 255, 255, 0.8);
        }

        * {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            outline: none;
            border: none;
            text-decoration: none;
        }

        body {
            background-image: url('images/img-13.jpg'); /* Your background image URL */
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .home-logo {
            position: absolute;
            top: 20px;
            right: 20px;
            z-index: 999;
        }

        .home-logo img {
            width: 50px; /* Adjust the width as needed */
        }

        .message {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            padding: 15px 20px;
            background-color: var(--orange);
            color: var(--white);
            font-size: 18px;
            border-radius: 8px;
            z-index: 9999;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .message:hover {
            transform: translateY(-5px) translateX(-50%);
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: var(--form-bg);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            width: 320px;
        }

        .form-container h3 {
            margin-bottom: 20px;
            text-align: center;
            color: var(--black);
            text-transform: uppercase;
        }

        .form-container input[type="email"],
        .form-container input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid var(--black);
            border-radius: 8px;
            box-sizing: border-box;
        }

        .form-container input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: var(--orange);
            border: none;
            color: var(--white);
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-container input[type="submit"]:hover {
            background-color: #f39c12;
        }

        .form-container p {
            text-align: center;
            margin-top: 15px;
            color: var(--black);
        }

        .form-container p a {
            color: var(--blue);
            text-decoration: none;
        }

        .form-container p a:hover {
            text-decoration: underline;
        }

        .error-message {
            text-align: center;
            color: var(--red);
            margin-top: 15px;
        }
    </style>
</head>
<body>
<?php
if(isset($message)){
    foreach($message as $message){
        echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
    }
}
?>
<div class="home-logo">
    <a href="home.php">
        <img src="home.png" alt="Home Logo">
    </a>
</div>

<div class="container">
    <div class="form-container">
        <form action="" method="POST">
            <h3>Login Now</h3>
            <input type="email" name="email" required placeholder="Enter email" class="box">
            <input type="password" name="password" required placeholder="Enter password" class="box">
            <input type="submit" name="submit" class="btn" value="Login Now">
            <p>Don't have an account? <a href="register.php">Register Now</a></p>
        </form>
    </div>
</div>
</body>
</html>