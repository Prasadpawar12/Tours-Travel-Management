<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];

    // Save the contact message to a file or database
    // Here, we'll just append it to a text file
    $file = 'contacts.txt';
    $current = file_get_contents($file);
    $current .= "Name: $name\nEmail: $email\nMessage: $message\n\n";
    file_put_contents($file, $current);

    // Redirect back to contact page after submission
    header("Location: index.php");
    exit();
} else {
    // If someone tries to access submit_contact.php directly, redirect them to contact page
    header("Location: index.php");
    exit();
}
?>
