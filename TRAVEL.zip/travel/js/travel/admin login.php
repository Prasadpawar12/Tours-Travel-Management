<?php
session_start();

// Check if the form is submitted
if(isset($_POST['login'])){
    // Establish database connection
    $connection = mysqli_connect('localhost','root','','admin');

    // Check if connection is successful
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Retrieve form data
    $id = $_POST['id'];
    $username = $_POST['username'];
    $email= $_POST['email'];
    $password = $_POST['password'];
    $

    // Prepare and execute SQL query to fetch admin credentials
    $query = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($connection, $query);

    // Check if there is a matching admin
    if(mysqli_num_rows($result) == 1){
        // Admin is authenticated, redirect to admin panel
        $_SESSION['admin'] = $username;
        header('Location: admin_panel.php');
        exit;
    } else {
        // Admin authentication failed, set error message
        $_SESSION['error_message'] = "Invalid username or password!";
        header('Location: admin_login_form.php');
        exit;
    }

    // Close connection
    mysqli_close($connection);
} else {
    // If form is not submitted, redirect to login page
    header('Location: admin_login_form.php');
    exit;
}
?>
